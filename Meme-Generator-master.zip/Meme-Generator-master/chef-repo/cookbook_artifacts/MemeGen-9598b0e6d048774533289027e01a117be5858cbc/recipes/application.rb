#
# Cookbook:: MemeGen
# Recipe:: application
#
# Copyright:: 2020, The Authors, All Rights Reserved.

Meme_Generator 'myapp'